# Musik Glass 🎵

Website musik bertema **liquid glass** ala Spotify. Mencari lagu & playlist dari seluruh dunia lewat **YouTube Data API v3**, memutar lewat pemutar resmi YouTube, dengan daftar lagu bernomor (1, 2, 3, …), antrean, acak, ulang, suka, simpan playlist, dan kontrol layar kunci (Media Session).

## 1. Upload sebagai website (pilih salah satu)
Folder yang diupload adalah **`www/`** (semuanya statis, tanpa build).
- **Netlify**: drag & drop folder `www` ke app.netlify.com/drop.
- **Vercel / Cloudflare Pages / GitHub Pages**: upload repo ini, *output directory* = `www`.
- Harus lewat **HTTPS** (semua layanan di atas otomatis HTTPS). Setelah live, buka di HP → menu browser → **Instal / Add to Home Screen** agar jadi aplikasi (PWA) dengan kontrol media di notifikasi.

## 2. Jadikan APK (tanpa install apa pun di komputer)
1. Buat repo GitHub, upload seluruh isi folder ini (termasuk `.github`).
2. Tab **Actions → Build APK → Run workflow**.
3. Setelah selesai (±5–8 menit), unduh artifact **musik-glass-apk** → `app-debug.apk` → install di Android.

Alternatif lokal: `npm install && npx cap add android && npx cap sync android && npx cap open android` (butuh Android Studio).

## 3. WAJIB: amankan API key
API key YouTube di aplikasi web **terlihat oleh siapa pun** yang membuka website. Di Google Cloud Console → Credentials → key Anda:
- *Application restrictions* → **HTTP referrers**: isi domain website Anda (dan `https://localhost/*` untuk APK).
- *API restrictions* → hanya **YouTube Data API v3**.
Key yang Anda kirim lewat chat sebaiknya dianggap bocor: **buat key baru** dan ganti di `www/js/config.js` (atau di menu Setelan aplikasi).
Kuota gratis 10.000 unit/hari; satu pencarian = 100 unit (≈100 pencarian/hari untuk seluruh pengguna).

## 4. Catatan jujur soal pemutaran latar belakang
- Pemutar YouTube resmi dibatasi oleh browser/OS: di Android Chrome (terutama setelah di-instal sebagai PWA) musik biasanya lanjut saat layar mati/pindah app; di **iPhone/Safari sering dijeda** saat keluar. Aplikasi sudah memakai Media Session, audio senyap penjaga, dan auto-resume, tetapi hasil akhirnya tergantung perangkat.
- Untuk APK, WebView memakai penyesuaian `onPause` (lihat `.github/workflows/android.yml`). Belum bisa saya uji di perangkat nyata.
- Sebagian video tidak boleh diputar di luar YouTube (error 101/150) → aplikasi otomatis lompat ke lagu berikutnya.
- Layanan seperti ini tunduk pada Ketentuan Layanan YouTube API; untuk publikasi Play Store, periksa kebijakannya dulu.
