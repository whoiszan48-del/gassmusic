/* Musik Glass — pencarian global via YouTube Data API v3 + pemutar YouTube IFrame */
(() => {
"use strict";

/* ---------- Util ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
const decodeHtml = (s = "") => { const t = document.createElement("textarea"); t.innerHTML = s; return t.value; };
const fmt = (s) => { s = Math.max(0, Math.floor(s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(x).padStart(2, "0")}` : `${m}:${String(x).padStart(2, "0")}`; };
const isoToSec = (iso = "") => { const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/); return m ? (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0) : 0; };
const el = (tag, props = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v; else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else if (v !== false && v != null) e.setAttribute(k, v);
  }
  kids.flat().forEach(c => c != null && e.append(c.nodeType ? c : document.createTextNode(c)));
  return e;
};
const thumbOf = (th = {}) => (th.high || th.medium || th.default || {}).url || "";
const cleanArtist = (s = "") => decodeHtml(s).replace(/\s*-\s*Topic$/i, "").replace(/VEVO$/i, "").trim();
const HEART = "M12 21s-8-5.3-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.7-8 11-8 11z";
const heartSvg = () => { const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"); s.setAttribute("viewBox", "0 0 24 24");
  const p = document.createElementNS("http://www.w3.org/2000/svg", "path"); p.setAttribute("d", HEART); s.append(p); return s; };

let toastTimer;
function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 3800);
}

/* ---------- State ---------- */
const state = {
  key: store.get("yt_key", "") || (window.APP_CONFIG && window.APP_CONFIG.YT_API_KEY) || "",
  region: store.get("region", (window.APP_CONFIG && window.APP_CONFIG.DEFAULT_REGION) || ""),
  liked: store.get("liked", []),          // track[]
  savedPl: store.get("savedPl", []),      // {id,title,channel,thumb}[]
  recent: store.get("recent", []),        // track[]
  queue: [], index: -1, shuffle: false, repeat: 0, // 0 off, 1 all, 2 one
  wantPlay: false, view: "home", searchTab: "song"
};

const REGIONS = [["", "🌍 Global"], ["ID", "🇮🇩 Indonesia"], ["US", "🇺🇸 Amerika"], ["GB", "🇬🇧 Inggris"], ["JP", "🇯🇵 Jepang"], ["KR", "🇰🇷 Korea"],
  ["IN", "🇮🇳 India"], ["BR", "🇧🇷 Brasil"], ["MX", "🇲🇽 Meksiko"], ["DE", "🇩🇪 Jerman"], ["FR", "🇫🇷 Prancis"], ["ES", "🇪🇸 Spanyol"],
  ["TR", "🇹🇷 Turki"], ["TH", "🇹🇭 Thailand"], ["PH", "🇵🇭 Filipina"], ["MY", "🇲🇾 Malaysia"], ["AU", "🇦🇺 Australia"], ["NG", "🇳🇬 Nigeria"], ["ZA", "🇿🇦 Afrika Selatan"]];
const GENRES = ["Pop", "Hip-Hop", "Rock", "K-Pop", "J-Pop", "EDM", "Lo-fi", "Jazz", "R&B", "Indie", "Dangdut", "Latin", "Reggae", "Klasik", "Metal", "Country"];

/* ---------- YouTube API ---------- */
async function yt(endpoint, params) {
  if (!state.key) throw new Error("API key belum diisi. Buka menu Setelan.");
  const url = new URL("https://www.googleapis.com/youtube/v3/" + endpoint);
  Object.entries({ ...params, key: state.key }).forEach(([k, v]) => v !== "" && v != null && url.searchParams.set(k, v));
  const ck = "c:" + url.pathname + url.search.replace(/key=[^&]+/, "");
  try { const c = sessionStorage.getItem(ck); if (c) { const o = JSON.parse(c); if (Date.now() - o.t < 600000) return o.d; } } catch {}
  let res;
  try { res = await fetch(url); } catch { throw new Error("Tidak ada koneksi internet."); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const r = data.error && data.error.errors && data.error.errors[0] && data.error.errors[0].reason;
    const map = { quotaExceeded: "Kuota harian YouTube API habis. Coba lagi besok atau pakai API key lain.",
      keyInvalid: "API key tidak valid. Periksa di Setelan.", ipRefererBlocked: "API key diblokir untuk domain ini. Tambahkan domain Anda di Google Cloud Console.",
      accessNotConfigured: "YouTube Data API v3 belum diaktifkan untuk key ini." };
    throw new Error(map[r] || (data.error && data.error.message) || "Permintaan gagal (" + res.status + ")");
  }
  try { sessionStorage.setItem(ck, JSON.stringify({ t: Date.now(), d: data })); } catch {}
  return data;
}

async function withDurations(tracks) {
  const ids = tracks.map(t => t.id).filter(Boolean);
  if (!ids.length) return tracks;
  try {
    const d = await yt("videos", { part: "contentDetails", id: ids.join(","), maxResults: 50 });
    const m = {}; (d.items || []).forEach(i => m[i.id] = isoToSec(i.contentDetails.duration));
    tracks.forEach(t => t.dur = m[t.id] || 0);
    return tracks.filter(t => t.dur > 0 || !(d.items || []).length);
  } catch { return tracks; }
}
const mkTrack = (id, sn) => ({ id, title: decodeHtml(sn.title), artist: cleanArtist(sn.videoOwnerChannelTitle || sn.channelTitle), thumb: thumbOf(sn.thumbnails), dur: 0 });

async function fetchTrending(region) {
  const d = await yt("videos", { part: "snippet,contentDetails", chart: "mostPopular", videoCategoryId: 10, regionCode: region || "US", maxResults: 25 });
  return (d.items || []).map(i => ({ ...mkTrack(i.id, i.snippet), dur: isoToSec(i.contentDetails.duration) }));
}
async function searchSongs(q, pageToken = "") {
  const d = await yt("search", { part: "snippet", type: "video", videoCategoryId: 10, videoEmbeddable: "true", q, maxResults: 25, regionCode: state.region, pageToken, safeSearch: "none" });
  const tracks = await withDurations((d.items || []).filter(i => i.id && i.id.videoId).map(i => mkTrack(i.id.videoId, i.snippet)));
  return { tracks, next: d.nextPageToken || "" };
}
async function searchPlaylists(q, pageToken = "") {
  const d = await yt("search", { part: "snippet", type: "playlist", q, maxResults: 24, regionCode: state.region, pageToken });
  return { lists: (d.items || []).filter(i => i.id && i.id.playlistId).map(i => ({ id: i.id.playlistId, title: decodeHtml(i.snippet.title), channel: cleanArtist(i.snippet.channelTitle), thumb: thumbOf(i.snippet.thumbnails) })), next: d.nextPageToken || "" };
}
async function fetchPlaylistItems(id, pageToken = "") {
  const d = await yt("playlistItems", { part: "snippet,contentDetails", playlistId: id, maxResults: 50, pageToken });
  const raw = (d.items || []).filter(i => i.snippet && i.snippet.title !== "Private video" && i.snippet.title !== "Deleted video" && i.contentDetails && i.contentDetails.videoId)
    .map(i => mkTrack(i.contentDetails.videoId, i.snippet));
  return { tracks: await withDurations(raw), next: d.nextPageToken || "" };
}

/* ---------- Player ---------- */
let player = null, playerReady = false, pendingLoad = null, tick = null, silentAudio = null;

function makeSilentAudio() {
  // Audio senyap yang di-loop agar browser menganggap halaman sedang memutar media (membantu playback saat layar mati / app di-background)
  const sr = 8000, n = sr, buf = new ArrayBuffer(44 + n), v = new DataView(buf);
  const w = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, "RIFF"); v.setUint32(4, 36 + n, true); w(8, "WAVEfmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr, true); v.setUint16(32, 1, true); v.setUint16(34, 8, true); w(36, "data"); v.setUint32(40, n, true);
  new Uint8Array(buf, 44).fill(128);
  const a = new Audio(URL.createObjectURL(new Blob([buf], { type: "audio/wav" }))); a.loop = true; a.setAttribute("playsinline", ""); return a;
}

function loadYT() {
  if (window.YT && window.YT.Player) return initPlayer();
  window.onYouTubeIframeAPIReady = initPlayer;
  const s = document.createElement("script"); s.src = "https://www.youtube.com/iframe_api"; s.async = true;
  s.onerror = () => toast("Gagal memuat pemutar YouTube. Periksa koneksi internet.");
  document.head.append(s);
}
function initPlayer() {
  const vars = { playsinline: 1, controls: 1, rel: 0, modestbranding: 1, fs: 1, iv_load_policy: 3 };
  if (/^https?:$/.test(location.protocol)) vars.origin = location.origin;
  player = new YT.Player("ytplayer", {
    width: "100%", height: "100%", playerVars: vars,
    events: {
      onReady: () => { playerReady = true; player.setVolume(+$("#npVol").value); if (pendingLoad) { player.loadVideoById(pendingLoad); pendingLoad = null; } },
      onStateChange: onPlayerState,
      onError: (e) => {
        const msgs = { 2: "ID video tidak valid", 5: "Error pemutar", 100: "Video tidak ditemukan", 101: "Pemilik video melarang diputar di luar YouTube", 150: "Pemilik video melarang diputar di luar YouTube", 153: "Pemutar ditolak (referer)" };
        toast((msgs[e.data] || "Lagu tidak bisa diputar") + " — lanjut ke lagu berikutnya");
        if (state.queue.length > 1) setTimeout(() => next(true), 900);
      }
    }
  });
}

function onPlayerState(e) {
  const S = YT.PlayerState;
  if (e.data === S.PLAYING) { setPlayingUI(true); state.wantPlay = true; startSilent(); }
  else if (e.data === S.PAUSED) {
    // Jika browser menjeda otomatis saat di-background padahal pengguna ingin lanjut, coba putar lagi
    if (state.wantPlay && document.hidden) { setTimeout(() => { try { if (state.wantPlay) player.playVideo(); } catch {} }, 250); }
    else setPlayingUI(false);
  }
  else if (e.data === S.ENDED) { if (state.repeat === 2) { player.seekTo(0); player.playVideo(); } else next(true); }
  else if (e.data === S.CUED || e.data === S.UNSTARTED) { /* menunggu */ }
}
function startSilent() { try { if (!silentAudio) silentAudio = makeSilentAudio(); silentAudio.play().catch(() => {}); } catch {} }
function stopSilent() { try { silentAudio && silentAudio.pause(); } catch {} }

function setPlayingUI(p) {
  $("#icPlay").hidden = p; $("#icPause").hidden = !p; $("#miniIcPlay").hidden = p; $("#miniIcPause").hidden = !p;
  if ("mediaSession" in navigator) navigator.mediaSession.playbackState = p ? "playing" : "paused";
  if (!p) stopSilent();
}

function current() { return state.queue[state.index]; }

function playQueue(tracks, index, openSheet = false) {
  if (!tracks.length) return;
  state.queue = tracks.slice(); state.index = index;
  loadCurrent(); renderQueue(); markCurrent();
  if (openSheet) openNP(true);
}
function loadCurrent() {
  const t = current(); if (!t) return;
  state.wantPlay = true; startSilent();
  if (playerReady) player.loadVideoById(t.id); else pendingLoad = t.id;
  updateMeta(t); pushRecent(t);
}
function updateMeta(t) {
  $("#npTitle").textContent = t.title; $("#npArtist").textContent = t.artist;
  $("#miniTitle").textContent = t.title; $("#miniArtist").textContent = t.artist; $("#miniArt").src = t.thumb || "";
  $("#npDur").textContent = fmt(t.dur); document.title = t.title + " · Musik Glass";
  syncLike();
  if ("mediaSession" in navigator) {
    const art = t.thumb ? [{ src: t.thumb, sizes: "480x360", type: "image/jpeg" }] : [];
    navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, album: "Musik Glass", artwork: art });
  }
}
function pushRecent(t) { state.recent = [t, ...state.recent.filter(x => x.id !== t.id)].slice(0, 30); store.set("recent", state.recent); }

function toggle() {
  if (!player || !playerReady) { if (current()) loadCurrent(); return; }
  const st = player.getPlayerState();
  if (st === YT.PlayerState.PLAYING || st === YT.PlayerState.BUFFERING) { state.wantPlay = false; player.pauseVideo(); setPlayingUI(false); }
  else { state.wantPlay = true; startSilent(); player.playVideo(); }
}
function next(auto = false) {
  if (!state.queue.length) return;
  const n = state.queue.length;
  if (state.shuffle && n > 1) { let i; do { i = Math.floor(Math.random() * n); } while (i === state.index); state.index = i; }
  else if (state.index + 1 < n) state.index++;
  else if (state.repeat === 1 || !auto) state.index = 0;
  else { state.wantPlay = false; setPlayingUI(false); return; }
  loadCurrent(); markCurrent();
}
function prev() {
  if (!state.queue.length) return;
  if (playerReady && player.getCurrentTime && player.getCurrentTime() > 4) { player.seekTo(0); return; }
  state.index = state.index > 0 ? state.index - 1 : state.queue.length - 1;
  loadCurrent(); markCurrent();
}

/* progress */
function startTick() {
  clearInterval(tick);
  tick = setInterval(() => {
    if (!playerReady || !player.getCurrentTime) return;
    const cur = player.getCurrentTime() || 0, dur = player.getDuration() || (current() && current().dur) || 0;
    if (!seeking && dur) { const p = cur / dur * 1000; const s = $("#npSeek"); s.value = p; s.style.setProperty("--p", p / 10 + "%"); $("#npCur").textContent = fmt(cur); $("#miniBar").style.width = p / 10 + "%"; }
    $("#npDur").textContent = fmt(dur);
    if ("mediaSession" in navigator && navigator.mediaSession.setPositionState && dur && isFinite(dur)) {
      try { navigator.mediaSession.setPositionState({ duration: dur, position: Math.min(cur, dur), playbackRate: 1 }); } catch {}
    }
  }, 500);
}
let seeking = false;

function setupMediaSession() {
  if (!("mediaSession" in navigator)) return;
  const set = (a, f) => { try { navigator.mediaSession.setActionHandler(a, f); } catch {} };
  set("play", () => { state.wantPlay = true; startSilent(); player && player.playVideo(); });
  set("pause", () => { state.wantPlay = false; player && player.pauseVideo(); setPlayingUI(false); });
  set("previoustrack", prev); set("nexttrack", () => next(false));
  set("seekto", (d) => { if (player && d.seekTime != null) player.seekTo(d.seekTime, true); });
  set("seekforward", (d) => player && player.seekTo(player.getCurrentTime() + (d.seekOffset || 10), true));
  set("seekbackward", (d) => player && player.seekTo(Math.max(0, player.getCurrentTime() - (d.seekOffset || 10)), true));
}

/* ---------- Rendering ---------- */
const isLiked = (id) => state.liked.some(t => t.id === id);
function toggleLike(t) {
  if (!t) return;
  state.liked = isLiked(t.id) ? state.liked.filter(x => x.id !== t.id) : [t, ...state.liked];
  store.set("liked", state.liked); syncLike();
  $$(".lk[data-id='" + t.id + "']").forEach(b => b.classList.toggle("on", isLiked(t.id)));
  if (state.view === "library") renderLibrary();
}
function syncLike() { const t = current(); $("#btnLike").classList.toggle("on", !!t && isLiked(t.id)); }

/* Daftar lagu bernomor: 1, 2, 3, … */
function trackList(tracks, { onPlay } = {}) {
  const ol = el("ol", { class: "tracklist" });
  tracks.forEach((t, i) => {
    const li = el("li", { class: "track", "data-id": t.id, role: "button", tabindex: "0", "aria-label": `${i + 1}. ${t.title} — ${t.artist}` },
      el("div", { class: "num" }, el("span", { text: String(i + 1) })),
      el("img", { src: t.thumb, alt: "", loading: "lazy" }),
      el("div", { class: "meta" }, el("div", { class: "t", text: t.title }), el("div", { class: "a", text: t.artist })),
      el("div", { class: "d", text: t.dur ? fmt(t.dur) : "" }),
      (() => { const b = el("button", { class: "lk" + (isLiked(t.id) ? " on" : ""), "data-id": t.id, "aria-label": "Suka", onclick: (e) => { e.stopPropagation(); toggleLike(t); } }); b.append(heartSvg()); return b; })()
    );
    const go = () => (onPlay ? onPlay(i) : playQueue(tracks, i));
    li.addEventListener("click", go);
    li.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    ol.append(li);
  });
  return ol;
}
function markCurrent() {
  const t = current();
  $$("#queueList .track").forEach((li, i) => li.classList.toggle("current", i === state.index));
  $$(".view .track").forEach(li => li.classList.toggle("current", !!t && li.dataset.id === t.id));
}
function renderQueue() {
  const box = $("#queueList"); box.replaceChildren();
  state.queue.forEach((t, i) => {
    const li = el("li", { class: "track" + (i === state.index ? " current" : ""), "data-id": t.id, role: "button", tabindex: "0" },
      el("div", { class: "num" }, el("span", { text: String(i + 1) })),
      el("img", { src: t.thumb, alt: "", loading: "lazy" }),
      el("div", { class: "meta" }, el("div", { class: "t", text: t.title }), el("div", { class: "a", text: t.artist })),
      el("div", { class: "d", text: t.dur ? fmt(t.dur) : "" }), el("span"));
    li.addEventListener("click", () => { state.index = i; loadCurrent(); markCurrent(); });
    box.append(li);
  });
}

const card = (img, title, sub, onclick, badge) => el("button", { class: "card", onclick },
  el("img", { src: img, alt: "", loading: "lazy" }), badge ? el("span", { class: "badge", text: badge }) : null, el("b", { text: title }), el("span", { text: sub }));
const loading = (t = "Memuat…") => el("div", { class: "loading" }, el("div", { class: "spinner" }), t);
const errBox = (e, retry) => el("div", { class: "empty" }, el("p", { text: "⚠️ " + e.message }), retry ? el("button", { class: "btn", onclick: retry, text: "Coba lagi" }) : null);

function show(view) {
  state.view = view;
  $$(".view").forEach(v => v.classList.toggle("active", v.id === "view-" + view));
  $$(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $("#main").scrollTo({ top: 0, behavior: "instant" });
  if (view === "library") renderLibrary(); if (view === "settings") renderSettings(); if (view === "search" && !$("#view-search").children.length) renderSearch("");
  if (view === "home" && !$("#view-home").children.length) renderHome();
}

/* Beranda */
async function renderHome() {
  const v = $("#view-home"); v.replaceChildren(el("h1", { text: "Selamat datang 👋" }));
  const chips = el("div", { class: "chips" }, ...GENRES.map(g => el("button", { class: "chip", text: g, onclick: () => { $("#q").value = g + " music"; doSearch(g + " music", "playlist"); } })));
  v.append(chips);
  const regionName = (REGIONS.find(r => r[0] === state.region) || REGIONS[0])[1];
  v.append(el("h2", { text: "Lagu populer — " + regionName }));
  const holder = el("div"); holder.append(loading()); v.append(holder);
  try {
    const tracks = await fetchTrending(state.region);
    holder.replaceChildren(el("div", { class: "actions" }, el("button", { class: "btn primary", text: "▶ Putar semua", onclick: () => playQueue(tracks, 0) }),
      el("button", { class: "btn", text: "🔀 Acak", onclick: () => { state.shuffle = true; syncToggles(); playQueue(tracks, Math.floor(Math.random() * tracks.length)); } })),
      trackList(tracks));
    markCurrent();
  } catch (e) { holder.replaceChildren(errBox(e, renderHome)); }
  if (state.recent.length) { v.append(el("h2", { text: "Terakhir diputar" }), trackList(state.recent.slice(0, 10))); }
}

/* Pencarian */
let lastQuery = "";
function doSearch(q, tab) { if (tab) state.searchTab = tab; lastQuery = q.trim(); show("search"); renderSearch(lastQuery); }
async function renderSearch(q) {
  const v = $("#view-search"); v.replaceChildren();
  if (!q) {
    v.append(el("h1", { text: "Jelajahi" }), el("div", { class: "chips" }, ...GENRES.map(g => el("button", { class: "chip", text: g, onclick: () => { $("#q").value = g; doSearch(g, "playlist"); } }))),
      el("div", { class: "empty", text: "Ketik nama lagu, artis, atau playlist di kolom pencarian." }));
    return;
  }
  const tabs = el("div", { class: "chips" },
    el("button", { class: "chip" + (state.searchTab === "song" ? " active" : ""), text: "Lagu", onclick: () => doSearch(q, "song") }),
    el("button", { class: "chip" + (state.searchTab === "playlist" ? " active" : ""), text: "Playlist", onclick: () => doSearch(q, "playlist") }));
  const out = el("div"); v.append(el("h1", { text: "Hasil untuk “" + q + "”" }), tabs, out); out.append(loading("Mencari…"));
  try {
    if (state.searchTab === "song") {
      let r = await searchSongs(q); let all = r.tracks; let tok = r.next;
      const render = () => {
        const list = trackList(all); const more = tok ? el("button", { class: "btn more", text: "Muat lebih banyak", onclick: async (e) => { e.target.disabled = true; try { r = await searchSongs(q, tok); all = all.concat(r.tracks); tok = r.next; render(); } catch (er) { toast(er.message); e.target.disabled = false; } } }) : null;
        out.replaceChildren(all.length ? el("div", { class: "actions" }, el("button", { class: "btn primary", text: "▶ Putar semua", onclick: () => playQueue(all, 0) })) : el("div", { class: "empty", text: "Tidak ada lagu ditemukan." }), list, more);
        markCurrent();
      }; render();
    } else {
      let r = await searchPlaylists(q); let all = r.lists; let tok = r.next;
      const render = () => {
        out.replaceChildren(all.length ? el("div", { class: "grid" }, ...all.map(p => card(p.thumb, p.title, p.channel, () => openPlaylist(p), "Playlist"))) : el("div", { class: "empty", text: "Tidak ada playlist ditemukan." }),
          tok ? el("button", { class: "btn more", text: "Muat lebih banyak", onclick: async (e) => { e.target.disabled = true; try { r = await searchPlaylists(q, tok); all = all.concat(r.lists); tok = r.next; render(); } catch (er) { toast(er.message); e.target.disabled = false; } } }) : null);
      }; render();
    }
  } catch (e) { out.replaceChildren(errBox(e, () => renderSearch(q))); }
}

/* Detail playlist */
async function openPlaylist(p) {
  const v = $("#view-playlist"); show("playlist"); $$(".nav-btn").forEach(b => b.classList.remove("active"));
  const saved = () => state.savedPl.some(x => x.id === p.id);
  v.replaceChildren(el("div", { class: "hero" }, el("img", { src: p.thumb, alt: "" }), el("div", {}, el("p", { text: "PLAYLIST" }), el("h1", { text: p.title }), el("p", { text: p.channel }))));
  const body = el("div"); body.append(loading()); v.append(body);
  try {
    let r = await fetchPlaylistItems(p.id); let all = r.tracks; let tok = r.next;
    const saveBtn = el("button", { class: "btn", text: saved() ? "✓ Tersimpan" : "＋ Simpan", onclick: (e) => {
      state.savedPl = saved() ? state.savedPl.filter(x => x.id !== p.id) : [p, ...state.savedPl]; store.set("savedPl", state.savedPl);
      e.target.textContent = saved() ? "✓ Tersimpan" : "＋ Simpan"; renderSidePlaylists(); } });
    const render = () => {
      body.replaceChildren(el("div", { class: "actions" }, el("button", { class: "btn primary", text: "▶ Putar", onclick: () => playQueue(all, 0) }),
        el("button", { class: "btn", text: "🔀 Acak", onclick: () => { state.shuffle = true; syncToggles(); playQueue(all, Math.floor(Math.random() * all.length)); } }), saveBtn),
        all.length ? trackList(all) : el("div", { class: "empty", text: "Playlist kosong atau tidak bisa diakses." }),
        tok ? el("button", { class: "btn more", text: "Muat lebih banyak", onclick: async (e) => { e.target.disabled = true; try { r = await fetchPlaylistItems(p.id, tok); all = all.concat(r.tracks); tok = r.next; render(); } catch (er) { toast(er.message); e.target.disabled = false; } } }) : null);
      markCurrent();
    }; render();
  } catch (e) { body.replaceChildren(errBox(e, () => openPlaylist(p))); }
}

/* Koleksi */
function renderLibrary() {
  const v = $("#view-library"); v.replaceChildren(el("h1", { text: "Koleksi Anda" }));
  v.append(el("h2", { text: "Lagu disukai" }));
  v.append(state.liked.length ? el("div", {}, el("div", { class: "actions" }, el("button", { class: "btn primary", text: "▶ Putar semua", onclick: () => playQueue(state.liked, 0) })), trackList(state.liked)) : el("div", { class: "empty", text: "Belum ada lagu yang disukai. Ketuk ♥ pada lagu." }));
  v.append(el("h2", { text: "Playlist tersimpan" }));
  v.append(state.savedPl.length ? el("div", { class: "grid" }, ...state.savedPl.map(p => card(p.thumb, p.title, p.channel, () => openPlaylist(p)))) : el("div", { class: "empty", text: "Belum ada playlist tersimpan." }));
  if (state.recent.length) v.append(el("h2", { text: "Riwayat" }), trackList(state.recent));
  markCurrent();
}
function renderSidePlaylists() {
  const box = $("#sidePlaylists"); box.replaceChildren();
  if (!state.savedPl.length) { box.append(el("span", { class: "empty", text: "Belum ada", style: "padding:6px 10px;display:block;text-align:left" })); return; }
  state.savedPl.forEach(p => box.append(el("button", { onclick: () => openPlaylist(p) }, el("img", { src: p.thumb, alt: "" }), el("span", { text: p.title }))));
}

/* Setelan */
function renderSettings() {
  const v = $("#view-settings"); v.replaceChildren(el("h1", { text: "Setelan" }));
  const inp = el("input", { type: "password", id: "keyInput", value: state.key, placeholder: "AIza…", autocomplete: "off", spellcheck: "false" });
  v.append(el("div", { class: "form" },
    el("label", { for: "keyInput", text: "YouTube Data API v3 key" }), inp,
    el("small", { text: "Disimpan hanya di perangkat ini. Pastikan key dibatasi (HTTP referrer / aplikasi Android) di Google Cloud Console." }),
    el("div", { class: "actions", style: "padding-left:0" },
      el("button", { class: "btn primary", text: "Simpan", onclick: () => { state.key = inp.value.trim(); store.set("yt_key", state.key); sessionStorage.clear(); toast("API key disimpan"); $("#view-home").replaceChildren(); } }),
      el("button", { class: "btn", text: "Hapus riwayat & suka", onclick: () => { state.recent = []; state.liked = []; store.set("recent", []); store.set("liked", []); toast("Data dihapus"); syncLike(); } })),
    el("small", { text: "Tips pemutaran latar belakang: pasang aplikasi ini ke layar utama (Instal / Add to Home Screen) agar musik tetap berjalan saat Anda berpindah aplikasi atau layar dimatikan." })));
}

/* ---------- Now playing UI ---------- */
function openNP(open) { $("#np").classList.toggle("open", open); if (open) { $("#np").scrollTop = 0; } }
function syncToggles() {
  $("#btnShuffle").classList.toggle("on", state.shuffle);
  const r = $("#btnRepeat"); r.classList.toggle("on", state.repeat > 0); $(".one", r).hidden = state.repeat !== 2;
}
function setRange(r) { r.style.setProperty("--p", (r.value - r.min) / (r.max - r.min) * 100 + "%"); }

/* ---------- Init ---------- */
function init() {
  // wilayah
  const sel = $("#region"); REGIONS.forEach(([c, n]) => sel.append(el("option", { value: c, text: n }))); sel.value = state.region;
  sel.addEventListener("change", () => { state.region = sel.value; store.set("region", state.region); $("#view-home").replaceChildren(); if (state.view === "home") renderHome(); else if (state.view === "search" && lastQuery) renderSearch(lastQuery); });

  $$(".nav-btn").forEach(b => b.addEventListener("click", () => show(b.dataset.view)));
  $("#searchForm").addEventListener("submit", (e) => { e.preventDefault(); $("#q").blur(); const q = $("#q").value.trim(); if (q) doSearch(q); });

  $("#btnPlay").onclick = toggle; $("#miniPlay").onclick = toggle;
  $("#btnNext").onclick = () => next(false); $("#miniNext").onclick = () => next(false);
  $("#btnPrev").onclick = prev; $("#miniPrev").onclick = prev;
  $("#btnShuffle").onclick = () => { state.shuffle = !state.shuffle; syncToggles(); };
  $("#btnRepeat").onclick = () => { state.repeat = (state.repeat + 1) % 3; syncToggles(); };
  $("#btnLike").onclick = () => toggleLike(current());
  $("#miniOpen").onclick = () => openNP(true); $("#npClose").onclick = () => openNP(false);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") openNP(false); });

  const seek = $("#npSeek");
  seek.addEventListener("input", () => { seeking = true; setRange(seek); if (player && player.getDuration) $("#npCur").textContent = fmt(seek.value / 1000 * player.getDuration()); });
  seek.addEventListener("change", () => { if (player && playerReady) player.seekTo(seek.value / 1000 * player.getDuration(), true); seeking = false; });
  const vol = $("#npVol"); setRange(vol); vol.addEventListener("input", () => { setRange(vol); player && playerReady && player.setVolume(+vol.value); });

  // lanjutkan musik jika kembali ke aplikasi
  document.addEventListener("visibilitychange", () => { if (!document.hidden && state.wantPlay && playerReady) { try { if (player.getPlayerState() === YT.PlayerState.PAUSED) player.playVideo(); } catch {} } });

  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register("sw.js").catch(() => {});

  setupMediaSession(); syncToggles(); renderSidePlaylists(); startTick(); loadYT(); renderHome();
}
document.addEventListener("DOMContentLoaded", init);
})();
