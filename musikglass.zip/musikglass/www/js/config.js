// Konfigurasi aplikasi. Ganti API key di sini, atau lewat menu Pengaturan di dalam aplikasi.
window.APP_CONFIG = {
  YT_API_KEY: "AIzaSyBihVf_Qpwf6JY1oUZwZpfIWw5rRHSfIto",
  DEFAULT_REGION: "" // "" = global, atau kode negara seperti "ID", "US"
};
